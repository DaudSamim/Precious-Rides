<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DriverNotification extends Model
{
    protected $table = 'driver_notification';
}
