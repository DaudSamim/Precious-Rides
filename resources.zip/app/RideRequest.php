<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RideRequest extends Model
{
    protected $table = 'ride_request';
}
