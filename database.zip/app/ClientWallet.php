<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientWallet extends Model
{

}
